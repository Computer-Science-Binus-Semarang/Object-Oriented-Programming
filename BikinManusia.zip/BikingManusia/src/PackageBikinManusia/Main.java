package PackageBikinManusia;

public class Main {
    public static void main(String[] args) {
        // Membuat Object dari Class Manusia
        Manusia orang1 = new Manusia("Budi", "Semarang", 25);
        Manusia orang2 = new Manusia("Siti", "Jakarta", 22);

        // Memanggil method dari object
        orang1.kenalan();
        orang2.kenalan();
    }
}
