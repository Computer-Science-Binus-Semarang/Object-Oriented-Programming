package PackageBikinManusia;

public class Manusia {
	
	String nama;
	String alamat;
	int umur;

	public Manusia(String nama, String alamat, int umur) {
		this.nama = nama;
        this.alamat = alamat;
        this.umur = umur;
	}
	
	public void kenalan() {
        System.out.println("Halo! Nama saya " + nama + ".");
        System.out.println("Saya tinggal di " + alamat + ".");
        System.out.println("Umur saya " + umur + " tahun.");
        System.out.println("----------------------------");
    }

}
